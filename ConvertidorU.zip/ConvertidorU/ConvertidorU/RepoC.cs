﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConvertidorU
{
    class RepoC
    {
        //Se encapsula los atributos que se utilizaran
        public double cm { get; set; }
        public double Me { get; set; }
        public double lt { get; set; }

    }
}
